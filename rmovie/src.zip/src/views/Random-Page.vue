<template>
    <div>
        <p>Random Page</p>
    </div>
</template>

