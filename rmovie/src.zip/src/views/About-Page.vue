<template>
    <div>
        <p>About Us Page</p>
    </div>
</template>
